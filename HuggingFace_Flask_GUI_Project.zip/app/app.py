
from flask import Flask, request, jsonify
from transformers import pipeline

app = Flask(__name__)
generator = pipeline('text-generation', model='gpt2')

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()
    user_input = data.get("input", "")
    result = generator(user_input, max_length=50)
    return jsonify(result)

if __name__ == "__main__":
    app.run(debug=True)
